﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelos
{
    class Empleado
    {
        public String Nombre { get; set; }
        public String Apellidos { get; set; }
        public String Usuario { get; set; }
        public String Contrasenia { get; set; }
        public String Puesto { get; set; }

        public Empleado(String nombre, String apellidos, String usuario, String contrasenia,
            String puesto)
        {
            Nombre = nombre;
            Apellidos = apellidos;
            Usuario = usuario;
            Contrasenia = contrasenia;
            Puesto = puesto;
        }
    }


}
